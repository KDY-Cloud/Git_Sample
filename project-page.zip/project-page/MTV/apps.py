from django.apps import AppConfig


class MtvConfig(AppConfig):
    name = 'MTV'
